
-- PART 1
-- TASK: Create a dimension model for patients
-- Reference raw_patients and stg_claims
-- Enrich patients with:
--   - First claim date
--   - Total number of claims
--   - Total claim amount
--   - Days since first claim



WITH patients AS (
    SELECT * FROM {{ ref('raw_patients') }}
),

-- Added logic to join with stg_claims
claims_data AS (
    SELECT
        patient_id,
        MIN(claim_date) AS first_claim_date,
        COUNT(*) AS total_claims,
        SUM(claim_amount) AS total_claim_amount
    FROM {{ ref('stg_claims') }}
    GROUP BY patient_id
),

final AS (
    SELECT
        p.*,
        c.first_claim_date,
        c.total_claims,
        c.total_claim_amount,
        CASE 
            WHEN c.first_claim_date IS NOT NULL 
            THEN DATE_DIFF(CURRENT_DATE(), c.first_claim_date, DAY)
            ELSE NULL
        END AS days_since_first_claim
    FROM patients p
    LEFT JOIN claims_data c ON p.patient_id = c.patient_id
)

SELECT * FROM final
