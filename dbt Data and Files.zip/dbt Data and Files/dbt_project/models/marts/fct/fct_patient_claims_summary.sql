

WITH base_claims AS (
    SELECT 
        c.claim_id,
        c.patient_id,
        c.claim_date,
        c.claim_amount,
        c.diagnosis_code,
        c.claim_month,
        p.first_claim_date,
        p.total_claims,
        p.days_since_first_claim,
        p.full_name,
        p.gender,
        p.age
    FROM {{ ref('stg_claims') }} c
    JOIN {{ ref('dim_patients') }} p
        ON c.patient_id = p.patient_id
),

claim_metrics AS (
    SELECT
        patient_id,
        full_name,
        gender,
        age,
        first_claim_date,
        days_since_first_claim,
        total_claims,
        
        -- Claim 
        SUM(claim_amount) AS lifetime_claim_amount,
        AVG(claim_amount) AS avg_claim_amount,
        MIN(claim_amount) AS min_claim_amount,
        MAX(claim_amount) AS max_claim_amount,
        
        -- Time 
        MIN(claim_date) AS earliest_claim_date,
        MAX(claim_date) AS latest_claim_date,
        DATE_DIFF(MAX(claim_date), MIN(claim_date), DAY) AS claim_activity_window_days,
        
        -- Diagnosis 
        COUNT(DISTINCT diagnosis_code) AS unique_diagnoses,
        ARRAY_AGG(DISTINCT diagnosis_code) AS all_diagnoses
    FROM base_claims
    GROUP BY 1, 2, 3, 4, 5, 6, 7
)

SELECT
    *,
    -- Derived 
    lifetime_claim_amount / NULLIF(total_claims, 0) AS cost_per_claim,
    total_claims / NULLIF(claim_activity_window_days, 0) * 365 AS annual_claim_rate,
    CASE
        WHEN days_since_first_claim > 365 THEN 'Established'
        WHEN days_since_first_claim BETWEEN 180 AND 365 THEN 'Developing'
        WHEN days_since_first_claim < 180 THEN 'New'
        ELSE 'No Claims'
    END AS patient_segment
FROM claim_metrics